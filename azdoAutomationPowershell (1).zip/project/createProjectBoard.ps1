param(
    [Parameter(Mandatory)]
    [string]$projectName,
    [Parameter(Mandatory)]
    [string]$orgName,
    [Parameter(Mandatory)]
    [string]$process,
    [Parameter(Mandatory)]
    [string]$description,
    [Parameter(Mandatory)]
    [string]$PAT)
# Import de modules
Import-Module  .\commonFunction -Force
Import-Module .\project\projectCommonFunctions -Force


# Definition de variables 
$org = "https://dev.azure.com/" + $orgName
$repoFeature = "ms.vss-code.version-control"
$pipelineFeature ="ms.vss-build.pipelines"
$artifactsFeature ="ms.azure-artifacts.feature"

# Fonctions
function New-Project {
    $createdProject = az devops project create `
        --name $projectName `
        --description $description `
        --org $org --visibility private `
        --process $process | ConvertFrom-Json
    return $createdProject  
}

# Input validation
if (IsProjectExisting -org $org -projectName $projectName) {
    Write-Error "Un projet avec le nom $projectName existe deja dans l'org $org"
    exit 1
}

# Main script 
$newProject = New-Project
Write-Output $newProject
$projectId = $newProject.id

Set-FeatureOff -org $org -projectId $projectId -feature $repoFeature -PAT $PAT
Set-FeatureOff -org $org -projectId $projectId -feature $pipelineFeature -PAT $PAT
Set-FeatureOff -org $org -projectId $projectId -feature $artifactsFeature -PAT $PAT


# What to do with the default team ?
# remove existing iterations ? sprint1,sprint2 ....



