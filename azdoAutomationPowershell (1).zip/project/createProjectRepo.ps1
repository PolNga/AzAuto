param(
    [Parameter(Mandatory)]
    [string]$projectName,
    [Parameter(Mandatory)]
    [string]$orgName,
    [Parameter(Mandatory)]
    [string]$process,
    [Parameter(Mandatory)]
    [string]$description,
    [Parameter(Mandatory)]
    [string]$PAT)
# Import de modules
Import-Module  .\commonFunction -Force
Import-Module .\project\projectCommonFunctions -Force

# Definition de variables 
$org = "https://dev.azure.com/" + $orgName
$boardsFeature = "ms.vss-work.agile"

# Fonctions
function New-Project {
    $createdProject = az devops project create `
        --name $projectName `
        --description $description `
        --org $org --visibility private `
        --process $process | ConvertFrom-Json
    return $createdProject  
}

# Input validation
if (IsProjectExisting -org $org -projectName $projectName) {
    Write-Error "Un projet avec le nom $projectName existe deja dans l'org $org"
    exit 1
}

# Main script 

$newProject = New-Project
Write-Output $newProject
$projectId = $newProject.id
Set-FeatureOff -org $org -projectId $projectId -feature $boardsFeature -PAT $PAT

# What to do with the default team ?

#$reposSecurityNameSpace = "Git Repositories"
# $namespaceId = Get-NameSpace -org $org -nameSpace $reposSecurityNameSpace
# $token = "repoV2/$($createdProject.id)/"
# # reinitialiser les acces pour le groupe readers: 
# $grpReaders = Get-GroupDescriptor -org $org -projectName $projectName -teamName "Readers"
# Reset-Permissions -org $org -nameSpace $namespaceId -subject $grpReaders -resourceToken $token
# # reinitialiser les acces pour le groupe readers: 
# $grpContributors = Get-GroupDescriptor -org $org -projectName $projectName -teamName "Contributors"
# Reset-Permissions -org $org -nameSpace $namespaceId -subject $grpContributors -resourceToken $token
#TODO supprimer le default team
#TODO reinitialiser les permissiosn pour readers pour les pipelines 
