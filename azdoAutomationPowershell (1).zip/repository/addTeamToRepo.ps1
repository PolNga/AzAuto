param(
    [Parameter(Mandatory)][string]$repoName,
    [Parameter(Mandatory)][string]$projectName,
    [Parameter(Mandatory)][string]$orgName,
    [Parameter(Mandatory)][string]$teamName)

Import-Module .\commonFunction -Force

$org = "https://dev.azure.com/" + $orgName
$securityNameSpace = "Git Repositories"
$contributorPermissionsNames = @('GenericRead', 'GenericContribute', 'CreateBranch', 'CreateTag', 'ManageNote', 'PullRequestContribute')

$repo = az repos list --org $org --project $projectName --query "[?@.name == '$repoName'] | [0]" | ConvertFrom-Json
if ($null -eq $repo) {
    Write-Error "Le repo $repoName n'existe pas dans le projet $projectName"
}
else {
    Write-Output "ajout de permissions pour l'equipe donnee sur le repo $($repo.name)"
    $team = Get-GroupDescriptor -org $org -projectName $projectName -teamName $teamName
    if ($null -ne $team) {
        $namespaceId = Get-NameSpace -org $org -nameSpace $securityNameSpace
        $allRepoPermissions = Get-NameSpacePermissions -org $org -nameSpaceId $namespaceId 
        $contributePermissions = ($allRepoPermissions  | Where-Object { $_.name -in $contributorPermissionsNames }).bit
        $token = "repoV2/$($repo.project.id)/$($repo.id)"
        Add-Permissions -org $org -nameSpace $namespaceId -subject $team -resourceToken $token -permissionBits $contributePermissions
    } 
    else {
        Write-Error "le team $teamName n'existe pas dans le projet $projectName"
    }
}