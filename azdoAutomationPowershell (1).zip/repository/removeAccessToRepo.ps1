param(
    [Parameter(Mandatory)][string]$repoName,
    [Parameter(Mandatory)][string]$projectName,
    [Parameter(Mandatory)][string]$orgName,
    [Parameter(Mandatory)][string]$teamName)

Import-Module  .\commonFunction -Force

$org = "https://dev.azure.com/" + $orgName
$securityNameSpace = "Git Repositories"

$repo = az repos list --org $org --project $projectName --query "[?@.name == '$repoName'] | [0]" | ConvertFrom-Json
if ($null -eq $repo) {
    Write-Error "Le repo $repoName n'existe pas dans le projet $projectName"
}
else {
    $team = Get-GroupDescriptor -org $org -projectName $projectName -teamName $teamName
    if ($null -ne $team) {
        Write-Output "reinitialisation de permissions pour l'equipe $teamName sur le repo $($repo.name)"
        $namespaceId = Get-NameSpace -org $org -nameSpace $securityNameSpace
        $token = "repoV2/$($repo.project.id)/$($repo.id)"
        $result = Reset-Permissions -org $org -nameSpace $namespaceId -subject $team -resourceToken $token

        if($result){
            Write-Output "permissions pour l'equipe $teamName sur le repo $($repo.name) reisnitalises"
        }else{
            Write-Error "les permissions pour l'equipe $teamName sur le repo $($repo.name) n'ont pas ete reinitialises"
        }
    } 
    else {
        Write-Error "le team $teamName n'existe pas dans le projet $projectName"
    }
}