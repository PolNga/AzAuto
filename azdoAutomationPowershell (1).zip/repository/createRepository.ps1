param(
    [Parameter(Mandatory)][string]$repoName,
    [Parameter(Mandatory)][string]$projectName,
    [Parameter(Mandatory)][string]$orgName,
    [Parameter(Mandatory)][string]$teamName)
# Import de modules
Import-Module  .\commonFunction -Force

# Definition de variables
$org = "https://dev.azure.com/" + $orgName
$repoNamePattern = "^R(D|SD|PR|CO)+-[a-zA-Z0-9]+-[a-zA-Z]+$"
$securityNameSpace = "Git Repositories"
$contributorPermissionsNames = @('GenericRead', 'GenericContribute', 'CreateBranch', 'CreateTag', 'ManageNote', 'PullRequestContribute')
$errorMsgPath = Join-Path "$PSScriptRoot" "errorMessage\repoNameError.txt"

# Validation des Input
if ( !(Get-PatternValidity -string $repoName -regex $repoNamePattern)) {
    Get-ErrorMsg -errorMsgPath $errorMsgPath
    exit 1
}



# Main Script
$repo = az repos list --org $org --project $projectName --query "[?@.name == '$repoName'] | [0]" | ConvertFrom-Json

if ($null -ne $repo) {
    Write-Error "Un repo avec le nom $repoName existe deja dans le projet $projectName"
}
else {
    Write-Output "Creation de repos"
    $createdRepo = az repos create --name $repoName --org $org --project $projectName | ConvertFrom-Json 
    Write-Output $createdRepo

    Write-Output "ajout de policies sur le repo $($createdRepo.name)"
    az repos policy case-enforcement create --blocking false --enabled  true --repository-id $createdRepo.id --org $org --project $projectName -o table
    az repos policy comment-required create --blocking false --enabled  true --repository-id $createdRepo.id --org $org --project $projectName --branch main -o table

    Write-Output "ajout de permissions pour l'equipe donnee sur le repo"
    $team = Get-GroupDescriptor -org $org -projectName $projectName -teamName $teamName
    if ($null -ne $team) {
        $namespaceId = Get-NameSpace -org $org -nameSpace $securityNameSpace
        $allRepoPermissions = Get-NameSpacePermissions -org $org -nameSpaceId $namespaceId 
        $contributePermissions = ($allRepoPermissions  | Where-Object { $_.name -in $contributorPermissionsNames }).bit
        $token = "repoV2/$($createdRepo.project.id)/$($createdRepo.id)"
        Add-Permissions -org $org -nameSpace $namespaceId -subject $team -resourceToken $token -permissionBits $contributePermissions
    }
    else {
        Write-Error "le team $teamName n'existe pas dans le projet $projectName"
    }
}
# add repo owners
    




