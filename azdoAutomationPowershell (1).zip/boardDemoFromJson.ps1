Function Create-Project ($project)
{
    & ".\project\createProjectBoard.ps1" -projectName $project.name -orgName $project.orgName -process $project.Process -description $project.description -PAT $project.pat
}

Function Create-Team ($team, $project)
{
    & ".\team\createTeamFromADgroup.ps1" -teamName $team.name -projectName $project.name -orgName $project.orgName -description $team.description -adGroupName $team.adGroupName
}

Function Create-Area ($area, $project)
{
    & ".\team\area\createAreaInProject.ps1" -projectName $project.name -orgName $project.orgName -areaName $area.name -path $area.path
}

Function Add-Area-to-Team ($teamAffectation, $project, $area)
{
    $absolutePath = "\$($project.name)"
    if ($null -ne $area.path) {
        $absolutePath += "\$($area.path)"
    }
    & ".\team\area\addAreatoTeam.ps1" -team $teamAffectation.team -projectName $project.name -orgName $project.orgName -path "$absolutePath\$($area.name)" -defaultArea $teamAffectation.isDefaultArea -permissions $teamAffectation.permissions
}

Function Create-Iteration ($iteration, $project)
{
    &  ".\team\iteration\createIterationInProject.ps1" -projectName $project.name  -orgName $project.orgName -iterationName $iteration.name -strartDate $iteration.startDate -finishDate $iteration.finishDate
}

Function Add-Iteration-to-Team ($iteration, $team, $project)
{
    & ".\team\iteration\addIterationToTeam.ps1" -team $team -projectName $project.name -orgName $project.orgName -iterationName $iteration.name
}
Function Main
{
    $projects = Get-Content -Path ".\config.json" | ConvertFrom-Json

    foreach ($project in $projects) {
        Create-Project $project

        foreach ($team in $project.teams) {
            Create-Team $team $project
        }

        foreach ($area in $project.area) {
            Create-Area $area $project
            
            foreach ($teamAffectation in $area.teamAffectation) {
                Add-Area-to-Team $teamAffectation $project $area
            }  
        }

        foreach ($iteration in $project.iterations) {
            Create-Iteration $iteration $project
            foreach($team in $iteration.teams){
                Add-Iteration-to-Team $iteration $team $project
            }
        }
    }
}

Main
