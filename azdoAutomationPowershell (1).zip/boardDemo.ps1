#create project : 
.\project\createProjectBoard.ps1 -projectName pro44 -orgName <Nom de votre Org> -process Agile -description desc -PAT <votre PAT>

#-Add teams :
.\team\createTeamFromADgroup.ps1 -teamName  123-R-team1 -projectName pro44 -orgName <Nom de votre Org> -description dreamteam -adGroupName team1
.\team\createTeamFromADgroup.ps1 -teamName  123-R-team2 -projectName pro44 -orgName <Nom de votre Org> -description dreamteam -adGroupName team2
.\team\createTeamFromADgroup.ps1 -teamName  123-R-mgmt -projectName pro44 -orgName <Nom de votre Org> -description dreamteam -adGroupName management

# create Areas

.\team\area\createAreaInProject.ps1 -projectName pro44 -orgName <Nom de votre Org> -areaName at1 
.\team\area\createAreaInProject.ps1 -projectName pro44 -orgName <Nom de votre Org> -areaName app1 -path at1 
.\team\area\createAreaInProject.ps1 -projectName pro44 -orgName <Nom de votre Org> -areaName app2 -path at1
.\team\area\createAreaInProject.ps1 -projectName pro44 -orgName <Nom de votre Org> -areaName at2 
.\team\area\createAreaInProject.ps1 -projectName pro44 -orgName <Nom de votre Org> -areaName app4 -path at2
.\team\area\createAreaInProject.ps1 -projectName pro44 -orgName <Nom de votre Org> -areaName app5 -path at2\app4

# Add team to area                  
                  
.\team\area\addAreatoTeam.ps1 -team 123-R-team1 -projectName pro44 -orgName <Nom de votre Org> -path  \pro44\at1 -defaultArea $true -permissions "GENERIC_READ","GENERIC_WRITE"
.\team\area\addAreatoTeam.ps1 -team 123-R-team2 -projectName pro44 -orgName <Nom de votre Org> -path  \pro44\at2 -defaultArea $true
.\team\area\addAreatoTeam.ps1 -team 123-R-mgmt -projectName pro44 -orgName <Nom de votre Org> -path  \pro44 -defaultArea $true

# create iterations

 .\team\iteration\createIterationInProject.ps1 -projectName pro44 -orgName <Nom de votre Org> -iterationName it1 -strartDate 2023-05-05 -finishDate 2023-05-23
 .\team\iteration\createIterationInProject.ps1 -projectName pro44 -orgName <Nom de votre Org> -iterationName it2 -strartDate 2023-05-05 -finishDate 2023-05-23
 .\team\iteration\createIterationInProject.ps1 -projectName pro44 -orgName <Nom de votre Org> -iterationName ita -path \pro44\Iteration\it1 -strartDate 2023-05-05 -finishDate 2023-05-23

 # Add Iteration to team 

 .\team\iteration\addIterationToTeam.ps1 -projectName pro44 -orgName <Nom de votre Org> -iterationName it1 -teamName 123-R-team1
 .\team\iteration\addIterationToTeam.ps1 -projectName pro44 -orgName <Nom de votre Org> -iterationName it2 -teamName 123-R-team2