# supprimer du groupe AD ?


# param(
#     [Parameter(Mandatory)]
#     [string]$teamName,
#     [Parameter(Mandatory)]
#     [string]$projectName,
#     [Parameter(Mandatory)]
#     [string]$orgName,
#     [Parameter(Mandatory)]
#     [array]$users)

# # Import de modules necessaires
# Import-Module  .\commonFunction -Force

# # declaration de variables 
# $org = "https://dev.azure.com/" + $orgName


# ###################### debut du script ###################### 
# $team = Get-GroupDescriptor -org $org -projectName $projectName -teamName $teamName
# if ($null -ne $team) {

#     foreach ($user in $users) {
#         $adoUser = az devops user show --user $user --org $org 
#         if ($null -ne $adoUser) {
        
#             Remove-GroupMember -org $org -member $user -group $team 
#         }
#         else {
#             Write-Output "L'utilisateur $user n'existe pas dans l'org $orgName"
#         }
    
#     }
# } 
# else {
#     Write-Error "le team/groupe $teamName n'existe pas dans le projet $projectName"
# }