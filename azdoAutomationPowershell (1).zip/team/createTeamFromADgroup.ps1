param(
    [Parameter(Mandatory)]
    [string]$teamName,
    [Parameter(Mandatory)]
    [string]$projectName,
    [Parameter(Mandatory)]
    [string]$orgName,
    [Parameter(Mandatory)]
    [string]$description,
    [Parameter(Mandatory)]
    [string]$adGroupName)

# Import de modules necessaires

Import-Module  .\commonFunction -Force

# Declaration de variables 

$org = "https://dev.azure.com/" + $orgName
$teamNamePattern = "^\d{3}-(T|R|D)-(?:\d{2}-)?\w+$"
$errorMsgPath = Join-Path "$PSScriptRoot" "errorMessage\teamNameError.txt"
# Validation des parametres 

if ( !(Get-PatternValidity -string $teamName -regex $teamNamePattern)) {
    Get-ErrorMsg -errorMsgPath $errorMsgPath
    exit 1
}

$existingTeam = Get-GroupDescriptor -org $org -projectName $projectName -teamName $teamName
if($null -ne $existingTeam){
    Write-Error "Une equie avec le nom $teamName existe deja dans le projet $projectName"
    exit 1
}

# Main Script 

$createdTeam = az devops team create --name $teamName --description $description `
                    --org $org `
                    --project $projectName | ConvertFrom-Json
Write-Output "Team $teamName created !"

$createdTeamDescriptor = $createdTeam.identity.subjectDescriptor
$adGroupId = az ad group show --group $adGroupName --query "@.id"
az devops security group create --origin-id  $adGroupId --groups $createdTeamDescriptor  --org $org --scope organization 


# Ajouter le groupe au groupe contributors pour que les utilisateurs puissent voir et contribuer le projet
$contrGroup = Get-GroupDescriptor -org $org -projectName $projectName -teamName "Contributors"
Add-GroupMember -org $org -member $createdTeamDescriptor -group $contrGroup

#Ajouter le backlog iteration pour l'equipe
$rootProjectIteration = az boards iteration project list --org $org --project $projectName --query "@.identifier"
az boards iteration team set-backlog-iteration --id $rootProjectIteration --team $teamName --project $projectName --org $org



