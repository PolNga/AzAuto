param(
    [Parameter(Mandatory)] [string]$projectName,
    [Parameter(Mandatory)] [string]$orgName,
    [Parameter(Mandatory)] [string]$iterationName,
    [Parameter(Mandatory)] [string]$teamName)

# Import de modules
Import-Module  .\commonFunction -Force

# Definition de variables 
$org = "https://dev.azure.com/" + $orgName

# Input validation
if (!(IsProjectExisting -org $org -projectName $projectName)) {
    Write-Error "le projet avec le nom $projectName n'existe pas dans l'org $org"
    exit 1
}
if(!(IsTeamExisting -org $org -projectName $projectName -teamName $teamName)){
  Write-Error "l'equipe $teamName n'existe pas dans le projet $projectName"
}

# utility functions
function GetIterationId {
  param (
      [object]$object)
  if ($object.name -eq $iterationName) {
    return $object.identifier
  } else {
    foreach ($child in $object.children) {
      $result = GetIterationId $child
      if ($result) {
        return $result
      }
    }
  }
  return $null
}

# Main Script
$projectIterations = az boards iteration project list --org $org --project $projectName --depth 4 | ConvertFrom-Json
$iterationId = GetIterationId -object $projectIterations 

if ($null -eq $iterationId){
  Write-Error "L'iteration $iterationId n'existe pas dans le projet $projectName"
}

az boards iteration team add --id $iterationId --team $teamName --org $org --project $projectName
