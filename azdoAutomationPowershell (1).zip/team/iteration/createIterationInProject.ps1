param(
    [Parameter(Mandatory)] [string]$projectName,
    [Parameter(Mandatory)] [string]$orgName,
    [Parameter(Mandatory)] [string]$iterationName,
    [string]$path,
    [Parameter(Mandatory)] [string]$strartDate,
    [Parameter(Mandatory)] [string]$finishDate)

# Import de modules
Import-Module  .\commonFunction -Force

# Definition de variables 
$org = "https://dev.azure.com/" + $orgName

# Input validation
if (!(IsProjectExisting -org $org -projectName $projectName)) {
    Write-Error "le projet avec le nom $projectName n'existe pas dans l'org $org"
    exit 1
}

# Main script

$cmd = "az boards iteration project create --name $iterationName --project $projectName --org $org --start-date $strartDate --finish-date $finishDate"
if ($path) {
    $cmd += " " + "--path $path"
}
Write-Output $cmd

Invoke-Expression $cmd
