param(
    [Parameter(Mandatory)]
    [string]$teamName,
    [Parameter(Mandatory)]
    [string]$projectName,
    [Parameter(Mandatory)]
    [string]$orgName,
    [Parameter(Mandatory)]
    [array]$users)

# Import de modules necessaires
Import-Module  .\commonFunction -Force

# declaration de variables 
$org = "https://dev.azure.com/" + $orgName

###################### debut du script ###################### 
$team = Get-GroupDescriptor -org $org -projectName $projectName -teamName $teamName
if ($null -ne $team) {

    $deniedUsers = @()

    foreach ($user in $users) {
        $adoUser = az devops user show --user $user.email --org $org 
        $isUserLicenceValid = $true
        if ($null -eq $adoUser) {
        
            if ($null -eq $user.licenceType) {
                $isUserLicenceValid = $false
            }
            else {
                Write-Output "l'utilisateur $($user.email) n'existe pas dans l'org $orgName, ajout de l'utilisateur dans l'rg  $orgName"
                az devops user add --org $org --email-id $user.email --license-type $user.licenceType --output table
            }
        } 
        if ($isUserLicenceValid) {
            Add-GroupMember -org $org -member $user.email -group $team 
        }
        else {
            $deniedUsers += $user.email
        }
    }
    if($deniedUsers.Count -ne 0){
        Write-Error "Les utilisateurs $deniedUsers n'ont pas ete ajouter vu que vous n'avez que ces utilisateurs ne sont pas ajoutes a l'org et vous n'avez pas fourni de licence"
    }
} 
else {
    Write-Error "le team $teamName n'existe pas dans le projet $projectName"
}