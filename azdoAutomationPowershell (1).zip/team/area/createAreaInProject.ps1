# usage example :
# .\team\area\createAreaInProject.ps1 -projectName pro1 -orgName <Nom de votre Org> -areaName abc -path \pro1\area\area1 
param(
    [Parameter(Mandatory)]
    [string]$projectName,
    [Parameter(Mandatory)]
    [string]$orgName,
    [Parameter(Mandatory)]
    [string]$areaName,
    [string]$path)


# Import de modules
Import-Module  .\commonFunction -Force

# Definition de variables 
$org = "https://dev.azure.com/" + $orgName

# Input validation
if (!(IsProjectExisting -org $org -projectName $projectName)) {
    Write-Error "le projet avec le nom $projectName n'existe pas dans l'org $org"
    exit 1
}


# Main Script
$command = "az boards area project create --name $areaName --project $projectName --org $org"
if($path){

    $command += " "+"--path \$projectName\area\$path"
}
Write-Output $command
Invoke-Expression $command

# remove contributors group rights ? ? ?
