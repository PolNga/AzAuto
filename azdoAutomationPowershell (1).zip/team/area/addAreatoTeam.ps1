param(
    [Parameter(Mandatory)]
    [string]$teamName,
    [Parameter(Mandatory)]
    [string]$projectName,
    [Parameter(Mandatory)]
    [string]$orgName,
    [Parameter(Mandatory)]
    [string]$path,
    [Parameter(Mandatory)]
    [bool]$defaultArea,
    [array]$permissions)


# Import de modules
Import-Module  .\commonFunction -Force

# Definition de variables 
$org = "https://dev.azure.com/" + $orgName
$securityNameSpace = "CSS"


# Input validation
if (!(IsProjectExisting -org $org -projectName $projectName)) {
    Write-Error "le projet avec le nom $projectName n'existe pas dans l'org $org"
    exit 1
}

if (!(IsTeamExisting -org $org -projectName $projectName -teamName $teamName)) {
    Write-Error "l'equipe $teamName n'existe pas dans le projet $projectName"
}

# utility functions
function GetAreaId {
    param (
        [object]$object,
        [string]$areaName)
    if ($object.name -eq $areaName) {
        return $object.identifier
    }
    else {
        foreach ($child in $object.children) {
            $result = GetAreaId $child $areaName
            if ($result) {
                return $result
            }
        }
    }
    return $null
}

# # Main script
$cmd = "az boards area team add --team $teamName  --org $org --project $projectName --path $path --include-sub-areas "

if ($defaultArea) {
    $cmd += " --set-as-default "
}

Invoke-Expression $cmd 

# affecter a l'equipe des droits sur l'area
$projectAreas = az boards area project list --org $org --project $projectName --depth 5 | ConvertFrom-Json

$areaPathArray = $path -split "\\" | Where-Object { $_ }

$token = ""
foreach ($ap in $areaPathArray) {
    Write-Output "AP : $ap"
    $areaId = GetAreaId $projectAreas $ap
    if ($token.Length -ne 0) {
        $token += ":"
    }
    $token += "vstfs:///Classification/Node/$areaId"
}

$team = Get-GroupDescriptor -org $org -projectName $projectName -teamName $teamName
$namespaceId = Get-NameSpace -org $org -nameSpace $securityNameSpace
$allCssPermission = Get-NameSpacePermissions -org $org -nameSpaceId $namespaceId 
$permissionBits = ($allCssPermission  | Where-Object { $_.name -in $permissions }).bit
Add-Permissions -org $org -nameSpace $namespaceId -subject $team -resourceToken $token -permissionBits $permissionBits


