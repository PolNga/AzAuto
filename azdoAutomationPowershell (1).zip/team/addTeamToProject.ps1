param(
    [Parameter(Mandatory)]
    [string]$teamName,
    [Parameter(Mandatory)]
    [string]$projectName,
    [Parameter(Mandatory)]
    [string]$orgName,
    [Parameter(Mandatory)]
    [string]$description,
    [Parameter(Mandatory)]
    [array]$users)

# Import de modules necessaires

Import-Module  .\commonFunction -Force

# Declaration de variables 

$org = "https://dev.azure.com/" + $orgName
$teamNamePattern = "^\d{3}-(T|R|D)-(?:\d{2}-)?\w+$"
$errorMsgPath = Join-Path "$PSScriptRoot" "errorMessage\teamNameError.txt"
# Validation des parametres 

if ( !(Get-PatternValidity -string $teamName -regex $teamNamePattern)) {
    Get-ErrorMsg -errorMsgPath $errorMsgPath
    exit 1
}

$existingTeam = Get-GroupDescriptor -org $org -projectName $projectName -teamName $teamName
if($null -ne $existingTeam){
    Write-Error "Une equie avec le nom $teamName existe deja dans le projet $projectName"
    exit 1
}
# Main Script 

$createdGroup = az devops team create --name $teamName --description $description `
                    --org $org `
                    --project $projectName | ConvertFrom-Json
Write-Output "Team $teamName created !"

$createdTeamDescriptor = $createdGroup.identity.subjectDescriptor
foreach ($user in $users) {
    $adoUser = az devops user show --user $user.email --org $org 
    if ($null -eq $adoUser) {

        Write-Output "User $($user.email) does not exist in the org, adding user to org  $orgName"
        az devops user add --org $org --email-id $user.email --license-type $user.licenceType --output table
    } 
    Add-GroupMember -org $org -member $user.email -group $createdTeamDescriptor
}

# Ajouter le groupe au groupe readers pour que les utilisateurs puissent voir le projet
$readersGroup = Get-GroupDescriptor -org $org -projectName $projectName -teamName "Readers"
Add-GroupMember -org $org -member $createdTeamDescriptor -group $readersGroup

