
param(
    [Parameter(Mandatory)]
    [string]$projectName,
    [Parameter(Mandatory)]
    [string]$org,
    [Parameter(Mandatory)]
    [string]$areaName,
    [string]$path,
    [string]$teams)


# Main Script
$command = "az boards area project create --name $areaName --project $projectName --org $org"
$parentPath = "\$projectName\area"

#creation de l'area si elle n'existe pas
if ($path) {
    $parentPath += "\$path"
    $command += " " + "--path $parentPath"
}
$existingarea = az boards area project list --path $parentPath --org $org --project $projectName  --query "children[?@.name=='$areaName'] | [0]"

if ($null -eq $existingarea) {
    $area = Invoke-Expression $command 
    Write-Output "Area cree $area"
}
else {
    Write-Output "l'area $parentPath\$areaName existe deja"
}

# ajout des equipes a l'area 
$areaAbsolutePath = $projectName
if($path -ne ""){
    $areaAbsolutePath +="\$path"
}
$areaAbsolutePath += "\$areaName"

$teamsMap = [System.Text.RegularExpressions.Regex]::Unescape($teams) | ConvertFrom-Json
$teamsMap.psobject.properties | Foreach { 
    $teamName = $_.Name
    $isDefaultArea = $_.Value

    $cmd = "az boards area team add --team $teamName  --org $org --project $projectName --path $areaAbsolutePath --include-sub-areas "

    if ($isDefaultArea -eq "true") {
        $cmd += " --set-as-default "
    }
    Write-Output $cmd
    Invoke-Expression $cmd   

}



